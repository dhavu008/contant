<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Meta Information -->
	<meta charset="utf-8" />

	<meta name="robots" content="index, follow" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<meta name="keyword" content="resume, cv, portfolio, vcard, responsive, retina, jquery, css3, bootstrap, material CV, creative, designer, developer, online cv, online resume, powerful portfolio, professional" />

	<meta name="description" content="Devboy - Creative Personal Portfolio HTML5 Resume / CV / vCard Template for professional and personal website."/>
	
	<meta name="author" content="ThemeArray" />

	<!-- Site Title -->
	<title>Devboy - Personal Portfolio Template</title>

	<!-- google Font -->
	<link rel="preconnect" href="https://fonts.googleapis.com" />
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet" />

	<!-- favicon -->
	<link rel="shortcut icon" href="assets/images/favicon-dark.png" />

	<!-- Bootstrap v5.0.2-->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<!-- Fontawesome v5.15.3   -->
	<link rel="stylesheet" href="assets/css/fontawesome.min.css" />
	<link rel="stylesheet" href="assets/css/template-icons.css" />
	<!-- Animated Headline -->
	<link rel="stylesheet" href="assets/css/animatedheadline.css" />
	<!-- Simplebar -->
	<link rel="stylesheet" href="assets/css/simplebar.css" />
	<!-- Owl Carousel v2.3.4 -->
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css" />
	<!-- Slick Slider -->
	<link rel="stylesheet" href="assets/css/slick.css" />
	<!-- Main Style Sheet -->
	<link rel="stylesheet" href="assets/css/style.css" />
</head>

<body class="dark">
	<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Preloader Start
	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
	<div class="preloader">
		<div class="preloader-inner">
			<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
		</div>
	</div>
	<!--~~./ Preloader End ~~-->

	<header class="site-header navbar-collapse-toggle" id="navbar">
		<div class="nav-brand">
			<a href="index.html">D</a>
		</div>
		<!-- /.navbar-brand -->
		<div class="menu nav" data-simplebar>
			<ul class="list-unstyled">
				<li>
					<a href="#home" class="nav-link active">
						<svg viewBox="0 0 24 24" fill="#262626">
							<path d="M23.4 10.392C23.3993 10.3914 23.3987 10.3907 23.3982 10.3902L13.6081 0.600404C13.1908 0.182923 12.636 -0.046875 12.0458 -0.046875C11.4557 -0.046875 10.9009 0.182923 10.4834 0.600404L0.69839 10.3852C0.695094 10.3885 0.691615 10.392 0.688502 10.3953C-0.168433 11.2572 -0.166968 12.6555 0.692714 13.5152C1.08548 13.9082 1.60403 14.1356 2.15866 14.1596C2.18136 14.1618 2.20407 14.1629 2.22696 14.1629H2.61697V21.3674C2.61697 22.7932 3.77713 23.9532 5.20298 23.9532H9.03318C9.42155 23.9532 9.73631 23.6382 9.73631 23.25V17.6016C9.73631 16.951 10.2657 16.4218 10.9162 16.4218H13.1754C13.826 16.4218 14.3552 16.951 14.3552 17.6016V23.25C14.3552 23.6382 14.6699 23.9532 15.0583 23.9532H18.8885C20.3145 23.9532 21.4745 22.7932 21.4745 21.3674V14.1629H21.8363C22.4263 14.1629 22.9811 13.9331 23.3987 13.5154C24.2593 12.6544 24.2597 11.2535 23.4 10.392V10.392ZM22.4043 12.5211C22.2525 12.6729 22.0507 12.7566 21.8363 12.7566H20.7714C20.383 12.7566 20.0682 13.0714 20.0682 13.4597V21.3674C20.0682 22.0177 19.5391 22.5469 18.8885 22.5469H15.7614V17.6016C15.7614 16.1758 14.6014 15.0156 13.1754 15.0156H10.9162C9.49021 15.0156 8.33006 16.1758 8.33006 17.6016V22.5469H5.20298C4.55258 22.5469 4.02322 22.0177 4.02322 21.3674V13.4597C4.02322 13.0714 3.70847 12.7566 3.3201 12.7566H2.27347C2.26248 12.7559 2.25168 12.7553 2.24051 12.7552C2.03103 12.7515 1.83456 12.6684 1.68734 12.521C1.37423 12.2079 1.37423 11.6983 1.68734 11.385C1.68753 11.385 1.68753 11.3848 1.68771 11.3846L1.68826 11.3841L11.478 1.59467C11.6296 1.44287 11.8312 1.35938 12.0458 1.35938C12.2602 1.35938 12.4618 1.44287 12.6136 1.59467L22.4012 11.382C22.4027 11.3835 22.4043 11.385 22.4058 11.3864C22.7172 11.7001 22.7167 12.2086 22.4043 12.5211V12.5211Z"/>
						</svg>							
						HOME
					</a>
				</li>
				<li>
					<a href="#about" class="nav-link">
						<svg viewBox="0 0 22 24" fill="#262626">
							<path d="M10.9131 12.9319C10.9379 12.9319 10.9628 12.9319 10.9926 12.9319C11.0026 12.9319 11.0125 12.9319 11.0224 12.9319C11.0373 12.9319 11.0572 12.9319 11.0721 12.9319C12.5283 12.907 13.7062 12.3951 14.576 11.416C16.4894 9.25906 16.1713 5.5614 16.1365 5.20853C16.0123 2.55954 14.7599 1.29219 13.7261 0.700766C12.9558 0.258439 12.0562 0.0198799 11.0523 0H11.0175C11.0125 0 11.0026 0 10.9976 0H10.9678C10.4161 0 9.33264 0.0894595 8.29392 0.680886C7.25022 1.27231 5.97791 2.53966 5.85366 5.20853C5.81887 5.5614 5.50079 9.25906 7.41423 11.416C8.27901 12.3951 9.45689 12.907 10.9131 12.9319ZM7.18064 5.33278C7.18064 5.31787 7.18561 5.30296 7.18561 5.29302C7.34962 1.72955 9.87934 1.34686 10.9628 1.34686H10.9827C10.9926 1.34686 11.0075 1.34686 11.0224 1.34686C12.3643 1.37668 14.6455 1.92338 14.7996 5.29302C14.7996 5.30793 14.7996 5.32284 14.8046 5.33278C14.8096 5.36757 15.1575 8.74715 13.577 10.5264C12.9508 11.2321 12.1158 11.58 11.0175 11.59C11.0075 11.59 11.0026 11.59 10.9926 11.59C10.9827 11.59 10.9777 11.59 10.9678 11.59C9.87437 11.58 9.03444 11.2321 8.4132 10.5264C6.83772 8.75709 7.17567 5.3626 7.18064 5.33278Z" />
							<path d="M21.206 19.0649C21.206 19.0599 21.206 19.0549 21.206 19.0499C21.206 19.0102 21.201 18.9704 21.201 18.9257C21.1712 17.9416 21.1066 15.6405 18.9496 14.905C18.9347 14.9 18.9148 14.895 18.8999 14.8901C16.6585 14.3185 14.7947 13.0263 14.7749 13.0114C14.4717 12.7977 14.0542 12.8723 13.8405 13.1754C13.6268 13.4786 13.7013 13.8961 14.0045 14.1098C14.089 14.1694 16.0671 15.5461 18.5421 16.1823C19.7001 16.5948 19.8293 17.8323 19.8641 18.9655C19.8641 19.0102 19.8641 19.0499 19.8691 19.0897C19.8741 19.537 19.8442 20.2278 19.7647 20.6254C18.9596 21.0827 15.8036 22.6631 11.0026 22.6631C6.22153 22.6631 3.04572 21.0777 2.23561 20.6205C2.15609 20.2229 2.1213 19.532 2.13124 19.0847C2.13124 19.045 2.13621 19.0052 2.13621 18.9605C2.171 17.8273 2.30022 16.5898 3.45823 16.1773C5.93327 15.5411 7.91132 14.1595 7.99581 14.1048C8.29898 13.8911 8.37353 13.4736 8.15982 13.1705C7.94611 12.8673 7.52864 12.7927 7.22547 13.0065C7.20559 13.0214 5.35179 14.3136 3.10039 14.8851C3.08051 14.8901 3.0656 14.895 3.05069 14.9C0.893721 15.6405 0.829111 17.9416 0.799291 18.9207C0.799291 18.9655 0.799291 19.0052 0.794321 19.045C0.794321 19.0499 0.794321 19.0549 0.794321 19.0599C0.789351 19.3183 0.784382 20.6453 1.04779 21.3113C1.09749 21.4405 1.18695 21.5498 1.30623 21.6244C1.45533 21.7238 5.02874 24 11.0076 24C16.9865 24 20.5599 21.7188 20.709 21.6244C20.8233 21.5498 20.9177 21.4405 20.9674 21.3113C21.2159 20.6503 21.211 19.3233 21.206 19.0649Z" />
						</svg>
						ABOUT ME
					</a>
				</li>
				<li>
					<a href="#resume" class="nav-link">
						<svg viewBox="0 0 21 21" fill="#262626">
							<path d="M0 0V21H21V0H0ZM19.7695 1.23047V4.92581H1.23047V1.23047H19.7695ZM1.23047 19.7695V6.15628H19.7695V19.7695H1.23047Z" />
							<path d="M2.46237 2.46292H3.69378V3.69338H2.46237V2.46292Z" />
							<path d="M4.92525 2.46292H6.1567V3.69338H4.92525V2.46292Z" />
							<path d="M7.38833 2.46292H8.61978V3.69338H7.38833V2.46292Z" />
							<path d="M7.98303 12.0081C8.49516 11.5196 8.8152 10.8314 8.8152 10.0695C8.8152 8.59131 7.61266 7.38877 6.1345 7.38877C4.65634 7.38877 3.4538 8.59135 3.4538 10.0695C3.4538 10.8314 3.77385 11.5196 4.28597 12.0081C3.15189 12.6535 2.38534 13.8733 2.38534 15.2689V18.5371H9.88362V15.2689C9.88366 13.8733 9.11712 12.6535 7.98303 12.0081ZM4.68427 10.0694C4.68427 9.26975 5.33482 8.6192 6.1345 8.6192C6.93418 8.6192 7.58473 9.26979 7.58473 10.0694C7.58473 10.8691 6.93418 11.5197 6.1345 11.5197C5.33482 11.5197 4.68427 10.8691 4.68427 10.0694ZM8.65319 17.3066H3.61581V15.2688C3.61581 13.88 4.74571 12.7501 6.1345 12.7501C7.52329 12.7501 8.65315 13.88 8.65315 15.2688L8.65319 17.3066Z" />
							<path d="M11.1157 8.65335H18.5375V9.88382H11.1157V8.65335Z" />
							<path d="M11.1157 11.1162H18.5375V12.3467H11.1157V11.1162Z" />
							<path d="M11.1157 13.5791H18.5375V14.8096H11.1157V13.5791Z" />
							<path d="M11.1157 16.0421H18.5375V17.2725H11.1157V16.0421Z" />
						</svg>							
						RESUME
					</a>
				</li>
				<li>
					<a href="#service" class="nav-link">
						<svg viewBox="0 0 23 21" fill="#262626">
							<path d="M22.3304 3.08807C22.329 3.08807 22.3276 3.08789 22.3262 3.08789H16.2168V2.41406C16.2168 1.29944 15.3099 0.392578 14.1953 0.392578H8.80469C7.69006 0.392578 6.7832 1.29944 6.7832 2.41406V3.08789H0.673828C0.29866 3.08789 0 3.39532 0 3.76172V18.5859C0 19.7006 0.90686 20.6074 2.02148 20.6074H20.9785C22.0931 20.6074 23 19.7006 23 18.5859V3.77593C23 3.77505 23 3.77418 23 3.7733C22.9742 3.33075 22.702 3.09052 22.3304 3.08807V3.08807ZM8.13086 2.41406C8.13086 2.04258 8.4332 1.74023 8.80469 1.74023H14.1953C14.5668 1.74023 14.8691 2.04258 14.8691 2.41406V3.08789H8.13086V2.41406ZM21.3912 4.43555L19.2987 10.713C19.2069 10.9887 18.95 11.1738 18.6596 11.1738H14.8691V10.5C14.8691 10.1278 14.5675 9.82617 14.1953 9.82617H8.80469C8.4325 9.82617 8.13086 10.1278 8.13086 10.5V11.1738H4.3404C4.04999 11.1738 3.79309 10.9887 3.70132 10.713L1.60876 4.43555H21.3912ZM13.5215 11.1738V12.5215H9.47852V11.1738H13.5215ZM21.6523 18.5859C21.6523 18.9574 21.35 19.2598 20.9785 19.2598H2.02148C1.65 19.2598 1.34766 18.9574 1.34766 18.5859V7.91401L2.4228 11.1393C2.6983 11.9661 3.46899 12.5215 4.3404 12.5215H8.13086V13.1953C8.13086 13.5675 8.4325 13.8691 8.80469 13.8691H14.1953C14.5675 13.8691 14.8691 13.5675 14.8691 13.1953V12.5215H18.6596C19.531 12.5215 20.3017 11.9661 20.5772 11.1393L21.6523 7.91401V18.5859Z" />
						</svg>							
						SERVICES
					</a>
				</li>
				<li>
					<a href="#portfolio" class="nav-link">
						<svg viewBox="0 0 26 21" fill="#262626" >
							<path d="M25.4797 7.56405C24.9556 6.89484 24.1042 6.49523 23.2021 6.49523H22.2946V5.66202C22.2946 4.13031 20.9276 2.88429 19.2475 2.88429H11.7182C11.3518 2.88429 11.0126 2.70365 10.8329 2.41272L10.2225 1.42364C9.68573 0.554265 8.66813 0.0141602 7.56701 0.0141602H3.04707C1.36693 0.0141602 0 1.25765 0 2.78593V17.6957C0 19.2272 1.36693 20.4732 3.04707 20.4732H18.9539C20.6886 20.4732 22.2327 19.4686 22.7962 17.9732C22.9785 17.4895 22.6963 16.963 22.1656 16.7968C21.6352 16.6306 21.0574 16.8879 20.8751 17.3716C20.5932 18.1191 19.8212 18.6216 18.9539 18.6216H5.9422C5.94538 18.6137 5.94875 18.6061 5.95172 18.5983L9.63773 8.81893C9.74405 8.53649 10.0356 8.34681 10.363 8.34681H23.2021C23.453 8.34681 23.6807 8.45368 23.8263 8.63992C23.9721 8.82598 24.009 9.05689 23.9275 9.27333L22.4537 13.1833C22.2714 13.667 22.5538 14.1938 23.0843 14.3599C23.6149 14.5261 24.1927 14.2686 24.3748 13.7851L25.8487 9.87491C26.1418 9.09721 26.0038 8.23326 25.4797 7.56405V7.56405ZM7.71637 8.21717L4.03037 17.9965C3.88953 18.3703 3.50351 18.6216 3.06989 18.6216H3.04707C2.48709 18.6216 2.03145 18.2063 2.03145 17.6957V2.78593C2.03145 2.27855 2.48709 1.86592 3.04707 1.86592H7.56701C7.93557 1.86592 8.27457 2.04439 8.45211 2.33189L9.06267 3.32079C9.60163 4.19378 10.6192 4.73605 11.7182 4.73605H19.2475C19.8077 4.73605 20.2633 5.15139 20.2633 5.66184V6.49523H10.363C9.1682 6.49523 8.10477 7.18723 7.71637 8.21717V8.21717Z" />
						</svg>							
						PORTFOLIO
					</a>
				</li>
				<li>
					<a href="#feedback" class="nav-link">
						<svg viewBox="0 0 25 25" fill="#262626" >
							<path d="M22.8027 0.78125H2.19727C0.985693 0.78125 0 1.76694 0 2.97852V17.627C0 18.8385 0.985693 19.8242 2.19727 19.8242H4.44336V23.4863C4.44336 23.7826 4.62183 24.0497 4.89551 24.163C5.16924 24.2763 5.48423 24.2137 5.6937 24.0042L9.87368 19.8242H22.8027C24.0143 19.8242 25 18.8385 25 17.627V2.97852C25 1.76694 24.0143 0.78125 22.8027 0.78125ZM23.5352 17.627C23.5352 18.0308 23.2066 18.3594 22.8027 18.3594H9.57031C9.37607 18.3594 9.18979 18.4366 9.05244 18.5739L5.9082 21.7181V19.0918C5.9082 18.6873 5.58027 18.3594 5.17578 18.3594H2.19727C1.79341 18.3594 1.46484 18.0308 1.46484 17.627V2.97852C1.46484 2.57466 1.79341 2.24609 2.19727 2.24609H22.8027C23.2066 2.24609 23.5352 2.57466 23.5352 2.97852V17.627Z"/>
							<path d="M17.4588 6.28677C16.8444 5.60386 15.9938 5.22778 15.0635 5.22778C14.0441 5.22778 13.1591 5.69233 12.5 6.57212C11.8409 5.69233 10.9559 5.22778 9.93652 5.22778C8.03008 5.22778 6.64062 6.79517 6.64062 8.71235C6.64062 9.70708 7.02563 10.6188 7.85225 11.5817C8.79971 12.6854 10.2726 13.8048 12.0233 15.3054C12.1605 15.4229 12.3302 15.4817 12.5 15.4817C12.6698 15.4817 12.8395 15.4229 12.9767 15.3054C14.7253 13.8066 16.2 12.6858 17.1478 11.5818C17.9744 10.6188 18.3594 9.70708 18.3594 8.71235C18.3594 7.7937 18.0396 6.93227 17.4588 6.28677ZM13.3609 13.0661C13.0817 13.2992 12.7962 13.5375 12.5 13.7877C12.2038 13.5374 11.9183 13.2992 11.6391 13.0661C9.4355 11.2267 8.10547 10.1164 8.10547 8.71235C8.10547 7.56094 8.89268 6.69263 9.93652 6.69263C11.294 6.69263 11.7746 8.28584 11.7956 8.35801C11.8851 8.67261 12.1726 8.88989 12.5 8.88989C12.8285 8.88989 13.1167 8.67124 13.2053 8.35493C13.2099 8.33833 13.6867 6.69263 15.0635 6.69263C16.1073 6.69263 16.8945 7.56094 16.8945 8.71235C16.8945 10.1164 15.5645 11.2267 13.3609 13.0661Z"/>
						</svg>
							
						FEEDBACK
					</a>
				</li>
				<li>
					<a href="#blog" class="nav-link">
						<svg viewBox="0 0 25 26" fill="#262626">
							<path d="M22.0703 0.406006H2.92969C1.31416 0.406006 0 1.758 0 3.42002V20.0976C0 22.3135 1.75228 24.1163 3.90625 24.1163H14.9414C15.4808 24.1163 15.918 23.6665 15.918 23.1116C15.918 22.5567 15.4808 22.1069 14.9414 22.1069H3.90625C2.82936 22.1069 1.95312 21.2055 1.95312 20.0976V6.48427H23.0469V15.7273C23.0469 16.2822 23.484 16.7319 24.0234 16.7319C24.5628 16.7319 25 16.2822 25 15.7273V3.42002C25 1.758 23.6858 0.406006 22.0703 0.406006ZM18.1152 2.41535C18.6537 2.41535 19.0918 2.86608 19.0918 3.42002C19.0918 3.97397 18.6537 4.42469 18.1152 4.42469C17.5768 4.42469 17.1387 3.97397 17.1387 3.42002C17.1387 2.86608 17.5768 2.41535 18.1152 2.41535ZM22.998 3.42002C22.998 3.97397 22.5599 4.42469 22.0215 4.42469C21.483 4.42469 21.0449 3.97397 21.0449 3.42002C21.0449 2.86608 21.483 2.41535 22.0215 2.41535C22.5599 2.41535 22.998 2.86608 22.998 3.42002ZM1.95312 3.42002C1.95312 2.86608 2.39124 2.41535 2.92969 2.41535H15.3536C15.2451 2.7299 15.1855 3.0678 15.1855 3.42002C15.1855 3.79108 15.2514 4.14645 15.3711 4.47493H1.95312V3.42002ZM18.7931 14.4606C18.6794 14.3435 18.5394 14.2569 18.3855 14.2089L14.5416 13.0078C14.2008 12.9012 13.8308 12.994 13.5757 13.2499C13.3209 13.5058 13.2216 13.8841 13.3167 14.2373L14.4085 18.2923C14.4535 18.4593 14.5395 18.6114 14.6585 18.7338L19.9987 24.2381C20.5698 24.8256 21.3202 25.1196 22.0703 25.1196C22.8205 25.1196 23.5706 24.8256 24.1419 24.2381C25.2842 23.0629 25.2842 21.1509 24.1426 19.9765L18.7931 14.4606ZM15.6729 15.4612L17.5835 16.0583L21.1931 19.7801L19.8118 21.2011L16.2222 17.5013L15.6729 15.4612ZM22.7608 22.8173C22.3801 23.2091 21.7606 23.2091 21.3804 22.818L21.1916 22.6234L22.5727 21.2025L22.761 21.3966C23.1417 21.7883 23.1417 22.4256 22.7608 22.8173V22.8173Z" />
						</svg>
						BLOGS
					</a>
				</li>
			</ul>
		</div>
		<!-- /.menu -->
		<div class="contact-btn">
			<a href="#contact" class="stretched-link">CONTACT ME</a>
		</div>
		<!-- /.contact-btn -->
	</header>
	<div class="mob-header">
		<div class="d-flex align-items-center">
			<div class="nav-brand">
				<a href="index.html">D</a>
			</div>
			<button class="toggler-menu ms-auto me-2" title="Toggle Menu">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
	</div>
	<div class="mobile-menu">
		<div class="menu-header">
			<div class="hero-img">
				<img
					src="assets/images/hero-img-xs.webp"
					class="img-fluid"
					width="75"
					height="75"
					alt="Devboy - Personal Portfolio"
				/>
			</div>
			<!-- /.hero-img -->
			<h3>I'm Jonson</h3>
			<p class="ah-headline clip">
				<span class="ah-words-wrapper">
					<b class="is-visible">I am a UX/UI Designer</b>
					<b>I Develop Mobile Apps</b>
				</span>
			</p>
			<div class="close-menu"></div>
		</div>
		<!-- /.menu-header -->
	</div>

    <div class="main contact_message_wrapper">   
        <div class="content">
            <?php
                /*
                This first bit sets the email address that you want the form to be submitted to.
                You will need to change this value to a valid email address that you can access.
                */
                $webmaster_email = "youremail@mail.com";

                $name = $_REQUEST['client_name'] ;
                $email_address = $_REQUEST['client_email'] ;
                $subject = $_REQUEST['subject'] ;
                $message = $_REQUEST['client_message'] ;
                $msg =  "Name: " . $name . "\r\n" . 
                        "Email: " . $email_address . "\r\n" . 
                        "Subject: " . $subject . "\r\n" . 
                        "Message: " . $message ;

                function isInjected($str) {
                    $injections = array('(\n+)',
                    '(\r+)',
                    '(\t+)',
                    '(%0A+)',
                    '(%0D+)',
                    '(%08+)',
                    '(%09+)'
                    );
                    $inject = join('|', $injections);
                    $inject = "/$inject/i";
                    if(preg_match($inject,$str)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                // If the form fields are empty, redirect to the error page.
                if (empty($name) || empty($email_address)) {
                    ?>
                        <h1>Oops!</h1>
                        <p>Please ensure you have completed all fields before submitting the form. </p>
                        <p>Also ensure that there is only one valid email address.</p>
                    <?php
                }
                elseif ( isInjected($email_address) || isInjected($name)  || isInjected($message) ) {
                    ?>
                        <h1>Oops!</h1>
                        <p>Please ensure you have completed all fields before submitting the form. </p>
                        <p>Also ensure that there is only one valid email address.</p>
                    <?php
                }
                // If we passed all previous tests, send the email then redirect to the thank you page.
                else {
                    mail( "$webmaster_email", "Message from Devboy", $msg );
                    ?>
                        <h1>Thanks for Contacting to me!</h1>
                        <p>We appreciate that you took the time to send us message. Your Message has been sent to the Admin Panel.</p>
                        <p>We are getting back to you soon.</p>
                        <a href="index.html" class="theme-btn">Back to Home</a>
                    <?php
                }
            ?>
        </div>
    </div><!-- /.contact_message_wrapper -->

	<!-- Footer -->
	<footer class="site-footer">
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-lg-6">
					<p class="text-center text-lg-start">
						Copyright 2022 All Right Reserved
					</p>
				</div>
				<div class="col-lg-6">
					<ul class="social-media text-center text-lg-end mt-lg-0">
						<li class="list-inline-item">
							<a
								target="_blank"
								rel="noreferrer"
								title="Follow us on Twitter"
								href="https://twitter.com/">
								<i class="fab fa-twitter"></i>
							</a>
						</li>
						<li class="list-inline-item">
							<a
								target="_blank"
								rel="noreferrer"
								title="Follow us on pinterest"
								href="https://www.pinterest.com/">
								<i class="fab fa-pinterest-p"></i>
							</a>
						</li>
						<li class="list-inline-item">
							<a
								target="_blank"
								rel="noreferrer"
								title="follow us on Facebook"
								href="https://www.facebook.com/">
								<i class="fab fa-facebook-f"></i>
							</a>
						</li>
						<li class="list-inline-item">
							<a
								target="_blank"
								rel="noreferrer"
								title="Connected with us on Linkedin"
								href="https://www.linkedin.com/">
								<i class="fab fa-linkedin-in"></i>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>

	<!-- jQuery v3.6.0 -->
	<script src="assets/js/jquery-3.6.0.min.js"></script>
	<!-- Bootstrap v5.0.2 -->
	<script src="assets/js/bootstrap.bundle.min.js" async></script>
	<!-- Waypoints -->
	<script src="assets/js/waypoints.min.js"></script>
	<!-- jQuery UI -->
	<script src="assets/js/jquery-ui.min.js"></script>
	<!-- jQuery Counterup -->
	<script src="assets/js/jquery.counterup.min.js"></script>
	<!-- jQuery Animated Headline -->
	<script src="assets/js/jquery.animatedheadline.js"></script>
	<!-- Simplebar -->
	<script src="assets/js/simplebar.min.js"></script>
	<!-- Circle Progressbar -->
	<script src="assets/js/circle-progress.min.js"></script>
	<!-- Owl Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- Slick Carousel -->
	<script src="assets/js/slick.min.js"></script>
	<!-- Isotop Metafizzy -->
	<script src="assets/js/isotope.pkgd.min.js"></script>
	<script src="assets/js/packery-mode.pkgd.min.js"></script>
	<!-- Magnific Popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<!-- Main Scripts -->
	<script src="assets/js/custom.js"></script> 
</body>
</html>